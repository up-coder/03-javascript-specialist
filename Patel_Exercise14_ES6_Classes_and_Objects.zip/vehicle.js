class Vehicle {
    
    //constructor
    constructor(color, direction, currentSpeed, topSpeed){
        this._color = color;
        this._direction = direction;
        this._currentSpeed = currentSpeed;
        this._topSpeed = topSpeed;
        this._engineStarted = false;  //default value to determine whether vehicle is on or off. Engines start OFF.
    }
    
    //DEBUGGING METHOD
    info() {
        const info = `This vehicle is ${this._color}. It's travelling at ${this._direction} degrees to North, at a current speed of ${this._currentSpeed} mph. The top speed of this vehicle is ${this._topSpeed} mph. The engine is ${this._engineStarted}.`;
        return info;
    }
        
    //Methods
    accelerate() {
        //this._currentSpeed = currentSpeed;
        console.log(`The vehicle is accelerating.  The current speed is now ${this._currentSpeed}.`);
    }
    
    brake() {
        this._currentSpeed = 0;
        console.log(`The vehicle is braking.  The current speed is now ${this._currentSpeed}.`);
        
    }
    
    turnOn() {
        this._engineStarted = true;
        console.log("Engine started. The engine is now ON.");
    }
    
    turnOff() {
        this._engineStarted = false;
        console.log("Engine stopped. The engine is now OFF.");
        
    }
    
    turnLeft() {
        console.log("Vehicle is turning left");
        
    }
    
    turnRight() {
        console.log("Vehicle is turning right");
        
    }
    
    
    //Setter
    set direction(newDirection){
        if(newDirection >= 0 && newDirection <= 359) {
            this._direction = newDirection;
        } else {
            alert("Direction value is out of range.");
        }
    }
    
}




//bus child class
class Bus extends Vehicle {
    constructor(color, direction, currentSpeed, topSpeed, numberOfSeats){
        super(color, direction, currentSpeed, topSpeed);
        this._numberOfSeats = numberOfSeats;
    }
    
    //DEBUGGING METHOD
    info() {
        const info = `This vehicle is ${this._color}. It's travelling at ${this._direction} degrees to North, at a current speed of ${this._currentSpeed} mph. The top speed of this vehicle is ${this._topSpeed} mph. The engine is ${this._engineStarted}.  This vehicle has ${this._numberOfSeats} seats.`;
        return info;
    }
}




//ambulance child class
class Ambulance extends Vehicle {
    constructor(color, direction, currentSpeed, topSpeed){
        super(color, direction, currentSpeed, topSpeed);  
        this._sirenStatus = false; // default value for siren is false - siren off.
    }
    
    //DEBUGGING METHOD
    info() {
        const info = `This vehicle is ${this._color}. It's travelling at ${this._direction} degrees to North, at a current speed of ${this._currentSpeed} mph. The top speed of this vehicle is ${this._topSpeed} mph. The engine is ${this._engineStarted}. The siren is ${this._sirenStatus}.`;
        return info;
    }
    
    sirenOn() {
        this._sirenStatus = true;
        console.log("Siren has been turned ON.");
    }
    
    sirenOff() {
        this._sirenStatus = false;
        console.log("Siren has been turned OFF.");
    }
}