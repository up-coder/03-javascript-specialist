var Player = function(name, livesLeft, score, speed){
    //Properties
    this.name = name;
    this.livesLeft = livesLeft;
    this.score = score;
    this.speed = speed;
    this.gridLocationX = 0;
    this.gridLocationY = 0;
    
    //Methods
    Player.prototype.die= function()
    {
        alert("Game Over. You have " + this.livesLeft + " lives left.");
    },
    Player.prototype.moveLeft= function()
    {
        if(this.gridLocationX > 0){
            this.gridLocationX =- 1;
        } else
        {
           alert("You can't move left, you'll fall off the board."); //this creates an alert to let player know they can't move left any further
            this.gridLocationX = 9; //or this option is where the gridLocationX is moved back to 9 
        }
    },
    Player.prototype.moveRight= function()
    {
        if(this.gridLocationX < 9){
            this.gridLocationX =+ 1;
        } else 
        {
            alert("You can't move right, you'll fall off the board."); //this creates an alert to let player know they can't move right any further
            this.gridLocationX = 0; //or this option is where the gridLocationX is moved back to 0
        }
    },
    Player.prototype.moveUp= function()
    {
        if(this.gridLocationY > 0){
            this.gridLocationY =- 1;
        } else
        {
           alert("You can't move up, you'll fall off the board."); //this creates an alert to let player know they can't move up any further
            this.gridLocationY = 9; //or this option is where the gridLocationY is moved back to 9 
        }
    },
    Player.prototype.moveDown= function()
    {
        if(this.gridLocationY < 9){
            this.gridLocationY =+ 1;
        } else 
        {
            alert("You can't move down, you'll fall off the board."); //this creates an alert to let player know they can't move down any further
            this.gridLocationY = 0; //or this option is where the gridLocationY is moved back to 0
        }
    }   
}